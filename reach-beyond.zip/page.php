<?php
    get_header();
?>

<?php get_template_part('template-parts/home', 'page'); ?>

<?php
    get_footer();
?>