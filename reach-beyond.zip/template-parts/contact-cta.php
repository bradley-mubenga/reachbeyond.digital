<section class="contactCTA">
    <div>
        <h2>We're Ready To Help You</h2>
        <p>Reach out today and let's see how we can add value to your business.</p>
        <div class="contactCTADIV">
            <a href="/contact" class="whiteCTA">Contact Us</a>
        </div>
    </div>
</section>