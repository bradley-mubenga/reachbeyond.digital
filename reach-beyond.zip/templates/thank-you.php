<?php
/*
Template Name: Thank You Page
*/
?>
<?php
    get_header();
?>

<section class="thankYouPage">
    <h2>Thank you for contacting us, our team will be in touch with you shortly.</h2>
</section>
<?php
    get_footer();
?>